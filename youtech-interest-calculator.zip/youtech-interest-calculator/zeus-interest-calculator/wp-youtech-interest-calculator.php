<?php
/**
 * Plugin Name: Youtech Interest Calculator
   Plugin URI: https://github.com/allensmyllen/youtech-interest-calculator
   Description: This is a plugin that helps calculate interest rate on a specific amount a user selects. The interest rate is 5% of the selected amount. This plugin makes use of jquery UI css and javascript codes as well as bootsnipp slider snippet as the interface of the plugin .
   Author: Youtech Ng
   Author URI: https://github.com/allensmyllen
   Text Domain: youtecch-interest-calculator
   Domain Path: /languages/
   Version: 1.11.0
 */

// Constants
if (!defined("ABSPATH")) {
	exit(); // if absolute path is not defined, exit from the page.
}
if (!defined("YOUTECH_PLUGIN_DIR_PATH")) {
	define("YOUTECH_PLUGIN_DIR_PATH", plugin_dir_path(__FILE__));
}
if (!defined("YOUTECH_PLUGIN_URL")) {
	define("YOUTECH_PLUGIN_URL", plugins_url()."/youtech-interest-calculator");
}
define("PLUGIN_VERSION", "1.11.0");

// Function to include asset files :zeus_plugin_asset_files
function youtech_plugin_assets() {
	// css assets/css/custom.css
	wp_enqueue_style(
		"bootstrap", // unique name for the css file
		YOUTECH_PLUGIN_URL."/assets/css/bootstrap.min.css", // bootstrap.min.css file path
		'', // dependency on other files
		PLUGIN_VERSION //plugin version number
	);
	wp_enqueue_style(
		"zeus-custom", // unique name for the css file
		YOUTECH_PLUGIN_URL."/assets/css/custom.css", // custom style file path
		'', // dependency on other files
		PLUGIN_VERSION //plugin version number
	);
	wp_enqueue_style(
		"jqueryUi", // unique name for the css file
		YOUTECH_PLUGIN_URL."/assets/css/smoothness-jquery-ui.css", // jqueryui.css file path
		'', // dependency on other files
		PLUGIN_VERSION //plugin version number
	);

	// js files
	wp_enqueue_script("jquery");
	wp_enqueue_script(
		"bootstrap.min.js", // unique name for the js file
		YOUTECH_PLUGIN_URL."/assets/js/bootstrap.min.js", // bootstrap.min.js file path
		'', // dependency on other files
		PLUGIN_VERSION, //plugin version number
		true
	);
	wp_enqueue_script(
		"jqueryUi.min.js", // unique name for the js file
		YOUTECH_PLUGIN_URL."/assets/js/jquery-ui.min.js", // jqueryui.min.js file path
		'', // dependency on other files
		PLUGIN_VERSION, //plugin version number
		true
	);
	wp_enqueue_script(
		"youtech-custom-js", // unique name for the js file
		youtech_PLUGIN_URL."/assets/js/youtech.js", // youtech custom js file path
		'', // dependency on other files
		PLUGIN_VERSION, //plugin version number
		true
	);
}

add_action("init","youtech_plugin_assets");

// This function adds the plugin menu to wordpress sidebar menu in the order: page_title, menu_title,capability,menu_slug(url link),callback_function,plugin_icon_name,plugin_menu_position
function add_youtech_menu() {
	add_menu_page(
		"Youtech Interest Calculator",
		"Youtech Interest Calculator",
		"manage_options",
		"youtech-interest-calculator",
		"plugin_setup_function",
		"dashicons-chart-bar",
		26
	);

	/* 
	This function adds a submenu to the plugin in the order: parent_slug(Url link),page_title,menu_title,capability,menu_slug,callback_function 
	add_submenu_page(
		"youtech-interest-calculator",
		"Youtech Interest Calculator Plugin Instruction",
		"Plugin Instruction",
		"manage_options",
		"youtech-plugin-setup",
		"plugin_setup_function"
	);
	*/
}

// This function hooks a function to a specific action.
add_action("admin_menu","add_youtech_menu");


// Plugin setup function
function plugin_setup_function() {
	echo "<h1>Thank you for using Youtech!</h1>
		  <p>
		  	This plugin has been created with lots of love and ultimate simplicity in handling, what you need to do is copy the entire shortcode below into the page you want the plugin to appear and that is all. You may give your feedback to me on twitter <b>@talkto_allen</b>, i look forward to hearing from you.
		  <p>
		  <h3>Shortcode: [youtech-ic]</h3>
	";
}

// Youtech Plugin Shortcode
add_shortcode("youtech-ic","youtech_shortcode_function");

function youtech_shortcode_function() {
	// we're linking the plugin plugin UI file
	include_once YOUTECH_PLUGIN_DIR_PATH.'/views/youtech-calculator.php';
}
?>
