<div class="container">
	<div class="price-box">
		<form class="form-horizontal form-pricing" role="form">
			<div class="price-slider">
				<h4 class="great">Youtech Loan Calculator</h4>

				<div class="col-sm-12">
					<div id="slider"></div>
				</div>
			</div>

			<div class="price-form">
                <div class="form-group">
                    <label for="amount" class="col-sm-7 control-label">Amount To Be Borrowed (NGN): </label>
                    <div class="col-sm-5">
                        <input type="hidden" id="amount" class="form-control">

                        <p class="price lead" id="amount-label"></p>
                    </div>
                </div>
            </div>

            <div class="price-form">
                <div class="form-group">
                    <label for="amount" class="col-sm-7 control-label">Amount to Pay (5% interest)</label>
                   	<div class="col-sm-5">
                   		<!-- The amount borrowed plus interest is kept in this input -->
                        <input type="hidden" id="debt" class="form-control">

                        <p class="price lead" id="debt-label"></p>
                    </div>
                </div>
	        </div>
	    </form>
    </div>
</div>
</body>
</html>