jQuery(document).ready(function () {
	jQuery("#slider").slider({
        range: "min",
        animate: true,
        value: 1,
        min: 10000,
        max: 5000000,
        step: 10000,
        slide: function (event, ui) {
            update(1, ui.value); //changed
        }
    });

    //Added, set initial value.
    jQuery("#amount").val(10000);
    jQuery("#amount-label").text(10000);


    update();
});

//changed. now with parameter
function update(slider, val) {
    //changed. Now, directly take value from ui.value. if not set (initial, will use current value.)
    var $amount = slider == 1 ? val : jQuery("#amount").val();

    // update the loan amount
    jQuery("#amount").val($amount);
    jQuery("#amount-label").text($amount);

    // calculate the interes rate of 5% and add to the amount borrowed.
    var $interest = Number($amount) + (Number($amount) * 0.05);

    jQuery("#debt").val($interest);
    jQuery("#debt-label").text($interest);

    jQuery('#slider a').html('<label>' + $amount + '</label><div class="ui-slider-label-inner"></div>');
}